# Memory Game Project

## What is the Memory Game
This is fun game to test the user memory by hiding icons behind a set of cards. The user has to remember the icon behind each card and match the similar cards.

## Instructions
* Click on a card
* Try to memorize the icon behind each card to decrease the number of moves.
* Match cards properly with less moves and in faster time is the core of the game.
## How to use the code?
* Use "showCard()" function to save the clicked cards in an array and compare their innerHtml. In case of matching a set of classes added to the matched cards. 
In case of un matching a set of classes added to the matched cards. 
* Create a counter for the timer and to the number of moves the user makes while playing the game.
* Use the congratulations part to show the player the result of the game.
## Code Dependancies 
* You have to link this font "https://fonts.googleapis.com/css?family=Coda" in the head tag. 
* You can use animate.css library to add a meaningful animation to the game.
* To use animate.css in your website, simply drop the stylesheet into your document's `<head>`, 
and add the class `animated` to an element, along with any of the animation names. 
* You can change the icons of the card using "www.fontawesome.com" all you have to do is to link the library in the head of the page "https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css"
then go to the website and choose your perfered icons and add it in the form of "<i class="fa fa-star"></i>".



